package br.univates.easylibmanager;

public class Main
{

    public static void main(String[] args)
    {
        EasyLibManagerSystem sys = EasyLibManagerSystem.getInstance();
        sys.start(); 
    }

}
