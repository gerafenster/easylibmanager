CREATE DATABASE easylib_manager;
\c easylib_manager

-- CREATE TABLE usuario (
-- id BIGSERIAL NOT NULL PRIMARY KEY,
-- nome VARCHAR(50) NOT NULL,
-- sobrenome VARCHAR(50) NOT NULL,
-- login VARCHAR(50) NOT NULL,
-- senha VARCHAR(50) NOT NULL,
-- cpf VARCHAR(14) NOT NULL
-- );